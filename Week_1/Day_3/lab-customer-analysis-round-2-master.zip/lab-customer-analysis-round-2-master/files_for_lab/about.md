## Additional note

In the folder `files_for_lab`, you will find `csv_files` and `excel_files` sub-folders. Both contain the same files, just with different extensions (`.csv` and `.xlsx` respectively).

You will be using `.xlsx` files when working with Online Excel.
